/*
Задачи:
Найти метод проверки объединения ячеек в столбце
Исправить чтобы числитель/знаменатель не писался, если пара всегда
Придумать разбиение по группам
Разбить дисциплины на вид, препод, название
*/
package exceloperations;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;


import java.io.FileInputStream;
import java.io.IOException;


public class ReadingExcel {
    //Метод, возвращающий номер строки, с которой начинается таблица
    public static int skipTopRows(XSSFSheet sheet) {
        // Создаём переменную хронящую номер последний строки(кол-во строк)
        int rows = sheet.getLastRowNum();

        //r-строки, с-столбцы
        for (int r = 0; r < rows; r++) {
            //Получаем строку номера r
            XSSFRow row = sheet.getRow(r);
            //Если строка пустая, пропускаем
            if (row == null)
                continue;
            //Получаем ячейку номера c
            XSSFCell cell = row.getCell(0);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (cell == null || cell.getCellType() == CellType.BLANK)
                continue;
            //С помощью флага пропускаем все строки до строки с "День недели"
            if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().contains("Д")) {
                return r;
            }
        }
        return 0;
    }

    public static int skipLowRows(XSSFSheet sheet) {
        // Создаём переменную хронящую номер последний строки(кол-во строк)
        int rows = sheet.getLastRowNum();

        //r-строки, с-столбцы
        for (int r = rows; r >= 0; r--) {
            //Получаем строку номера r
            XSSFRow row = sheet.getRow(r);
            //Если строка пустая, пропускаем
            if (row == null)
                continue;
            //Получаем ячейку номера c
            XSSFCell cell = row.getCell(0);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (cell == null || cell.getCellType() == CellType.BLANK)
                continue;
            //С помощью флага пропускаем все строки до строки с "День недели"
            if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().contains("СОГЛ")) {
                return r;
            }
        }
        return 0;
    }

    //Метод возвращающий количество столбцов
    public static int numCols(XSSFSheet sheet) {
        // Cоздаём переменную хронящую кол-во ячеек в заданной строке - кол-во столбцов
        int cols = sheet.getRow(skipTopRows(sheet) + 1).getLastCellNum();
        //Получаем строку
        XSSFRow row = sheet.getRow(skipTopRows(sheet) + 1);

        while (true) {
            //Получаем ячейку номера cols
            XSSFCell cell = row.getCell(cols);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (cell == null || cell.getCellType() == CellType.BLANK)
                cols -= 1;
            else if (cell.getStringCellValue().contains("А")) {
                return cols + 1;
            }
        }
    }

    //Метод, который проверяет нужно ли выводить строку, проверя ячейки с дисциплинами на пустоту
    public static boolean skipExtraRow(XSSFRow row, int cols) {
        //Счётчик не пустых ячеек
        int countNONEmpty = 0;

        //c - индекс ячейки
        for (int c = 2; c < cols - 1; c++) {
            //Получаем ячейку индекса с
            XSSFCell cell = row.getCell(c);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (cell != null && cell.getCellType() != CellType.BLANK)
                countNONEmpty += 1;
        }

        //Если все ячейки пустые пропускаем, иначе - нет
        if (countNONEmpty == 0)
            return true;
        else
            return false;
    }

    /*Проверяет, объединены ли ячейки в строке.
    @return True, если ячейки в строке объединены, False - если нет.*/
    /*public static boolean CombInRow(XSSFRow row) {
        // Проверяем каждую ячейку в строке
        for (int cellIndex = 2; cellIndex < numCols(row.getSheet()) - 1; cellIndex++) {
            XSSFCell cell = row.getCell(cellIndex);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (cell == null)
                continue;

            // Получаем диапазон объединенных ячеек, к которому принадлежит данная ячейка
            CellRangeAddress mergedRegion = cell.getSheet().getMergedRegion(cellIndex);

            // Если диапазон объединенных ячеек не null и содержит больше чем одну ячейку,
            // то ячейки в строке объединены
            if (mergedRegion != null && mergedRegion.getNumberOfCells() > 1) {
                return true;
            }
        }

        // Если ни одна ячейка в строке не принадлежит диапазону объединенных ячеек,
        // то ячейки в строке не объединены
        return false;
    }*/

    //Метод, который проверяет объединение ячеек в столбце CombInCol
    /*public static boolean CombInCol(XSSFRow row){
    }*/

    //Метод из готового парсера, возвращаящий значение взависимости от полученного типа данных
    private static Object getValue(XSSFCell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN:
                return cell.getBooleanCellValue();
            case ERROR:
                return cell.getErrorCellValue();
            case FORMULA:
                return cell.getCellFormula();
            case BLANK, _NONE:
                return null;
            default:
                break;
        }
        return null;
    }


    public static void main(String[] args) throws IOException {

        // Прописываем место хранения файла (.// - текущий проект)
        String excelFilePath = ".//datafiles//RaspisanieIVT.xlsx";
        // Открытие файла
        FileInputStream inputstream = new FileInputStream(excelFilePath);
        // Описываем рабочую книгу
        XSSFWorkbook workbook = new XSSFWorkbook(inputstream);
        //Счётчик листов
        for (int numSheet = 0; numSheet < workbook.getNumberOfSheets(); numSheet++) {
            //Выводим номер листа для тестов программы
            System.out.println(numSheet + 1);

            // Описываем лист по индексу
            XSSFSheet sheet = workbook.getSheetAt(numSheet);

            ////// Чтение используя for

            // Создаём переменную хронящую номер последний строки(кол-во строк)
            int rows = skipLowRows(sheet);
            // Cоздаём переменную хронящую кол-во ячеек в заданной строке - кол-во столбцов
            int cols = numCols(sheet);

            //r-строки, с-столбцы
            for (int r = skipTopRows(sheet); r < rows; r++) {
                //Получаем строку номера r
                XSSFRow row = sheet.getRow(r);
                //Если строка пустая, пропускаем
                if (row == null)
                    continue;

                if (skipExtraRow(row, cols)) {
                    if (row.getCell(0) != null && row.getCell(0).getCellType() != CellType.BLANK)
                        System.out.println(getValue(row.getCell(0)));
                    if (row.getCell(1) != null && row.getCell(1).getCellType() != CellType.BLANK)
                        System.out.println(getValue(row.getCell(1)));
                    continue;
                }
                //Создаём флаг, чтобы не выводить первые 2 ячейки первых 2 строк
                boolean flag = false;
                boolean blocker = false;
                for (int c = 0; c < cols; c++) {
                    //Если первая или вторая строка таблицы, не выводим первые 2 ячейки
                    if((r == skipTopRows(sheet) || r == skipTopRows(sheet) + 1) && !flag) {
                        c += 2;
                        flag = true;
                    }
                    //Получаем ячейку номера c
                    XSSFCell cell = row.getCell(c);
                    //Пропускаем если ячейка пустая или внутри неё пробел
                    if (cell == null || cell.getCellType() == CellType.BLANK)
                        continue;
                    //Не выводим "Ауд."
                    if (r == skipTopRows(sheet) + 1 && cell.getStringCellValue().contains("А"))
                        continue;

                    if (r > skipTopRows(sheet) + 1) {
                        //Разделяем на числитель и знаменатель
                        if ((row.getCell(1) != null && row.getCell(1).getCellType() != CellType.BLANK) && (row.getCell(c) != null && row.getCell(c).getCellType() != CellType.BLANK) && !blocker && c > 1) {
                            System.out.println("ЧИСЛИТЕЛЬ");
                            blocker = true;
                        }
                        if ((row.getCell(1) == null || row.getCell(1).getCellType() == CellType.BLANK) && (row.getCell(c) != null && row.getCell(c).getCellType() != CellType.BLANK) && !blocker) {
                            System.out.println("ЗНАМЕНАТЕЛЬ");
                            blocker = true;
                        }
                    }
                    if (c == 1) {
                        switch (cell.getStringCellValue()) {
                            case "8.00 - 9.30":
                                System.out.println("8:00:00-9:30:00");
                                break;
                            case "9.40 - 11.10":
                                System.out.println("9:40:00-11:10:00");
                                break;
                            case "11.20 - 12.50":
                                System.out.println("11:20:00-12:50:00");
                                break;
                            case "13.10 - 14.40":
                                System.out.println("13:10:00-14:40:00");
                                break;
                            case "14.50 - 16.20":
                                System.out.println("14:50:00-16:20:00");
                                break;
                            case "16.30 – 18.00":
                                System.out.println("16:30:00-18:00:00");
                                break;
                            case "18.10 – 19.40":
                                System.out.println("18:10:00-19:40:00");
                                break;
                        }
                        continue;
                    }
                    //Выводим информацию из ячейки, в зависимости от типа
                    System.out.println(getValue(cell));
                }
                //Пропуск строки для удобства чтения
                System.out.println();
            }
        }
    }
}