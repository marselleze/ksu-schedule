package exceloperations;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadingExcel {
    //Метод проверяющий пустая ячейка или нет
    //true - не пустая
    //false - пустая
    public static boolean fullCell(XSSFCell cell) {
        if (cell != null && cell.getCellType() != CellType.BLANK)
            return true;
        else if (cell == null || cell.getCellType() == CellType.BLANK)
            return false;
        return false;
    }

    //Метод, возвращающий номер строки, с которой начинается таблица
    public static int skipTopRows(XSSFSheet sheet) {
        // Создаём переменную хронящую номер последний строки(кол-во строк)
        int rows = sheet.getLastRowNum();

        //r-строки, с-столбцы
        for (int r = 0; r < rows; r++) {
            //Получаем строку номера r
            XSSFRow row = sheet.getRow(r);
            //Если строка пустая, пропускаем
            if (row == null)
                continue;
            //Получаем ячейку номера c
            XSSFCell cell = row.getCell(0);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (!fullCell(cell))
                continue;
            //С помощью флага пропускаем все строки до строки с "День недели"
            if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().contains("Д")) {
                return r;
            }
        }
        return 0;
    }

    //Метод возвращающий номер последней строки в расписании
    public static int skipLowRows(XSSFSheet sheet) {
        // Создаём переменную хронящую номер последний строки(кол-во строк)
        int rows = sheet.getLastRowNum();

        //r-строки
        for (int r = rows; r >= 0; r--) {
            //Получаем строку номера r
            XSSFRow row = sheet.getRow(r);
            //Если строка пустая, пропускаем
            if (row == null)
                continue;
            //Получаем ячейку номера 1
            XSSFCell cell = row.getCell(0);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (!fullCell(cell))
                continue;
            //Если доходим до строки с "СОГЛАСОВАНО" возвращаем номер этой строки
            if (cell.getCellType() == CellType.STRING && (cell.getStringCellValue().contains("СОГЛ") || cell.getStringCellValue().contains("Согл"))) {
                return r;
            }
        }
        return 0;
    }

    //Метод возвращающий количество столбцов
    public static int numCols(XSSFSheet sheet) {
        // Cоздаём переменную хронящую кол-во ячеек в заданной строке - кол-во столбцов
        int cols = sheet.getRow(skipTopRows(sheet) + 1).getLastCellNum();
        //Получаем строку
        XSSFRow row = sheet.getRow(skipTopRows(sheet) + 1);

        while (true) {
            //Получаем ячейку номера cols
            XSSFCell cell = row.getCell(cols);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (!fullCell(cell))
                cols -= 1;
            else if (cell.getStringCellValue().contains("А")) {
                return cols + 1;
            }
        }
    }

    //Метод, который проверяет нужно ли выводить строку, проверя ячейки с дисциплинами на пустоту
    public static boolean skipExtraRow(XSSFRow row, int cols) {
        //Счётчик не пустых ячеек
        int countNONEmpty = 0;

        //c - индекс ячейки
        for (int c = 2; c < cols - 1; c++) {
            //Получаем ячейку индекса с
            XSSFCell cell = row.getCell(c);
            //Пропускаем если ячейка пустая или внутри неё пробел
            if (fullCell(cell))
                countNONEmpty += 1;
        }

        //Если все ячейки пустые пропускаем, иначе - нет
        if (countNONEmpty == 0)
            return true;
        else
            return false;
    }

    //Метод проверяющий пара делится на ЧИСЛИТЕЛЬ и ЗНАМЕНАТЕЛЬ или она ВСЕГДА
    //true - ЧИСЛИТЕЛЬ и ЗНАМЕНАТЕЛЬ
    //false - ВСЕГДА
    public static boolean numDenOrCom(XSSFSheet sheet, int r) {
        XSSFRow row2 = sheet.getRow(r + 1);
        XSSFCell cell = row2.getCell(2);
        if (fullCell(cell))
            return true;
        else
            return false;
    }

      /*Проверяет, объединены ли ячейки в строке xlsx-файла.

      @param row Строка, которую нужно проверить.
      @return True, если ячейки в строке объединены, False - если нет.

    public static boolean isRowMerged(XSSFRow row) {
        // Проверяем каждую ячейку в строке
        for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
            XSSFCell cell = row.getCell(cellIndex);

            // Получаем диапазон объединенных ячеек, к которому принадлежит данная ячейка
            CellRangeAddress mergedRegion = cell.getSheet().getMergedRegion(cellIndex);

            // Если диапазон объединенных ячеек не null и содержит больше чем одну ячейку,
            // то ячейки в строке объединены
            if (mergedRegion != null && mergedRegion.getNumberOfCells() > 1) {
                return true;
            }
        }

        // Если ни одна ячейка в строке не принадлежит диапазону объединенных ячеек,
        // то ячейки в строке не объединены
        return false;
    }*/

    /*//Метод проверящий делится ли пара на подгруппы или она общая
    public static boolean subgrpsOrGen (XSSFRow row){
        XSSFCell cell = row.getCell(numCols(row.getSheet()) - 1);
        if(fullCell(cell))
            return true;
        else
            return false;
    }*/

    //Метод из готового парсера, возвращаящий значение взависимости от полученного типа данных
    private static Object getValue(XSSFCell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN:
                return cell.getBooleanCellValue();
            case ERROR:
                return cell.getErrorCellValue();
            case FORMULA:
                return cell.getCellFormula();
            case BLANK, _NONE:
                return null;
            default:
                break;
        }
        return null;
    }


    public static void main(String[] args) throws IOException {

        // Прописываем место хранения файла (.// - текущий проект)
        String excelFilePath = ".//datafiles//RaspisanieIVT.xlsx";
        // Открытие файла
        FileInputStream inputstream = new FileInputStream(excelFilePath);
        // Описываем рабочую книгу
        XSSFWorkbook workbook = new XSSFWorkbook(inputstream);

        /////// Блок переменных для БД //////
        String day = "";
        String time;
        String[] fullTime;
        String startTime = "";
        String endTime = "";
        String nameDirection = "";
        String nameProfile = "";
        String subGroup = "";
        String numGroup = "";
        String nameDiscipline = "";
        String disciplineView = "";
        String teacherFCs = "";
        String teacherPost = "";
        String weekView = "";
        String numAuditorium = "";

        //Счётчик листов
        for (int numSheet = 0; numSheet < workbook.getNumberOfSheets(); numSheet++) {
            //Выводим номер листа для тестов программы
            System.out.println(numSheet + 1);
            // Описываем лист по индексу
            XSSFSheet sheet = workbook.getSheetAt(numSheet);

            ////// Чтение используя for //////

            // Создаём переменную хронящую номер последний строки(кол-во строк)
            int rows = skipLowRows(sheet);
            // Cоздаём переменную хронящую кол-во ячеек в заданной строке - кол-во столбцов
            int cols = numCols(sheet);
            //Переменная для контроля при делении пар на числитель и знаменатель
            int controlWeekView = skipTopRows(sheet) + 2;
            //Создаём переменную, которая будет хранить индекс первой ячейки с аудиториией
            int indexFirstAuditCell = 0;
                                    //Разбиваем направление
            int indexProf = 0;
            //Разбиваем строку на список
            List<String> fullName = new ArrayList<>(List.of(sheet.getRow(skipTopRows(sheet)).getCell(2).getStringCellValue().split(" ")));
            //Удаляем лишние пробелы
            fullName.remove("");
            //Удаляем лишние переносы строк
            for (int i = 0; i < fullName.size(); i++) {
                fullName.set(i, fullName.get(i).trim());
            }

            //i - индекс подстроки в списке
            for (int i = 0; i < fullName.size(); i++) {
                //Запоминаем индекс вида пары и должности препода
                if (fullName.get(i).contains("(")) {
                    indexProf = i - 1;
                    break;
                }
            }

            //Создаём 2 списка куда будем помещать направление и профиль
            List<String> direction = new ArrayList<>();
            List<String> profile = new ArrayList<>();

            //Заполняем списки нужными данными
            for (int listElms = 0; listElms < indexProf; listElms++) {
                direction.add(fullName.get(listElms));
            }
            for (int listElms = indexProf + 2; listElms < fullName.size(); listElms++) {
                profile.add(fullName.get(listElms));
            }

            //Создаём переменные для удобства переноса данных в БД

            //Вывод направления
            nameDirection = String.join(" ", direction);
            //Следующую строку меняешь на добавление в БД
            //System.out.println(nameDirection);
            //Вывод профиля
            nameProfile = String.join(" ", profile);
            //Следующую строку меняешь на добавление в БД
            //System.out.println(nameProfile);
            //Направление
            System.out.println(nameDirection);
            //Профиль
            System.out.println(nameProfile);

                                /////Получаем номер группы////
            for (int c = 2; c < cols - 1; c += 2){

                if (!fullCell(sheet.getRow(skipTopRows(sheet) + 1).getCell(c)))
                    continue;

                String[] fullGroup = sheet.getRow(skipTopRows(sheet) + 1).getCell(c).getStringCellValue().split(" ");
                String groupAndSub = fullGroup[1];
                fullGroup = groupAndSub.split("\\.");
                if(!(numGroup.equals(fullGroup[0]))) {
                    numGroup = fullGroup[0];
                    //Номер группы
                    System.out.println(numGroup);
                }
            }

            //r-строки, с-столбцы
            for (int r = skipTopRows(sheet) + 1; r < rows; r++) {


                //Создаём флаг, который помогает запомнить индекс ячейки для определения аудитории
                boolean flag = false;
                //Создаём вспомогательную переменную для удобного вывода номера аудиторий
                int auditCell = indexFirstAuditCell;
                //Получаем строку номера r
                XSSFRow row = sheet.getRow(r);
                //Если строка пустая, пропускаем
                if (row == null)
                    continue;
                //Пропускаяем пустые строки, выводим только день недели и время
                if (skipExtraRow(row, cols)) {
                    if (fullCell(row.getCell(0))) {
                        //Переменная хранящая день недели
                        day = String.valueOf(row.getCell(0));
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(day);
                    }
                    if (fullCell(row.getCell(1))) {

                        switch (row.getCell(1).getStringCellValue()) {
                            case "8.00 - 9.30":
                                time = "8:00:00-9:30:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "9.40 - 11.10":
                                time = "9:40:00-11:10:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "11.20 - 12.50":
                                time = "11:20:00-12:50:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "13.10 - 14.40":
                                time = "13:10:00-14:40:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "14.50 - 16.20":
                                time = "14:50:00-16:20:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "16.30 – 18.00":
                                time = "16:30:00-18:00:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "18.10 – 19.40":
                                time = "18:10:00-19:40:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                        }
                    }
                    continue;
                }

                for (int c = 0; c < cols; c++) {

                    //Если первая или вторая строка таблицы, не выводим первые 2 ячейки
                    if (r == skipTopRows(sheet)) {
                        c += 2;
                    }

                    //Получаем ячейку номера c
                    XSSFCell cell = row.getCell(c);

                    //Пропускаем если ячейка пустая или внутри неё пробел
                    if (!fullCell(cell))
                        continue;

                    //Не выводим "Ауд."
                    if (r == skipTopRows(sheet) + 1 && cell.getStringCellValue().contains("А")) {
                        if (!flag) {
                            indexFirstAuditCell = c;
                            flag = true;
                        }
                        continue;
                    }

                    //Разбиваем время
                    if (c == 1) {
                        switch (cell.getStringCellValue()) {
                            case "8.00 - 9.30":
                                time = "8:00:00-9:30:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "9.40 - 11.10":
                                time = "9:40:00-11:10:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "11.20 - 12.50":
                                time = "11:20:00-12:50:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "13.10 - 14.40":
                                time = "13:10:00-14:40:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "14.50 - 16.20":
                                time = "14:50:00-16:20:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "16.30 – 18.00":
                                time = "16:30:00-18:00:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                            case "18.10 – 19.40":
                                time = "18:10:00-19:40:00";
                                fullTime = time.split("-");
                                //Время начала
                                startTime = fullTime[0];
                                //Время конца
                                endTime = fullTime[1];
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(startTime);
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(endTime);
                                break;
                        }
                        continue;
                    }

                    /*//Разбиваем направление
                    if (r == skipTopRows(sheet)) {

                        int indexProf = 0;

                        //Разбиваем строку на список
                        List<String> fullName = new ArrayList<>(List.of(cell.getStringCellValue().split(" ")));
                        //Удаляем лишние пробелы
                        fullName.remove("");
                        //Удаляем лишние переносы строк
                        for (int i = 0; i < fullName.size(); i++) {
                            fullName.set(i, fullName.get(i).trim());
                        }

                        //i - индекс подстроки в списке
                        for (int i = 0; i < fullName.size(); i++) {
                            //Запоминаем индекс вида пары и должности препода
                            if (fullName.get(i).contains("(")) {
                                indexProf = i - 1;
                                break;
                            }
                        }

                        //Создаём 2 списка куда будем помещать направление и профиль
                        List<String> direction = new ArrayList<>();
                        List<String> profile = new ArrayList<>();

                        //Заполняем списки нужными данными
                        for (int listElms = 0; listElms < indexProf; listElms++) {
                            direction.add(fullName.get(listElms));
                        }
                        for (int listElms = indexProf + 2; listElms < fullName.size(); listElms++) {
                            profile.add(fullName.get(listElms));
                        }

                        //Создаём переменные для удобства переноса данных в БД

                        //Вывод направления
                        nameDirection = String.join(" ", direction);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(nameDirection);
                        //Вывод профиля
                        nameProfile = String.join(" ", profile);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(nameProfile);
                        continue;
                    }*/

                    //Разбиваем группы, получаем номер группы и подгрупп
                    if (r == skipTopRows(sheet) + 1) {
                        //Создаём массив из слов
                        String[] fullNumGroup = cell.getStringCellValue().split(" ");
                        //Получем номер подгруппы
                        subGroup = fullNumGroup[1];
                        /*//Разбиваем номер подгруппы
                        fullNumGroup = subGroup.split("\\.");
                        //Получаем номер группы
                        numGroup = fullNumGroup[0];
                        if(!blockerGroup) {
                            //Следующую строку меняешь на добавление в БД
                            System.out.println(numGroup);
                            blockerGroup = true;
                        }*/
                        //Следующую строку меняешь на добавление в БД
                        System.out.println(subGroup);
                        continue;
                    }

                    //Разбиваем дисциплину
                    if (r > skipTopRows(sheet) + 1 && (c > 1 && c % 2 == 0 && c != cols - 1) && cell.getCellType() == CellType.STRING) {
                        int indexView = 0;
                        int indexPost = 0;
                        //Разбиваем строку на список
                        List<String> fullNameDiscip = new ArrayList<>(List.of(cell.getStringCellValue().split(" ")));
                        //Удаляем лишние пробелы
                        fullNameDiscip.remove("");
                        //Удаляем лишние переносы строк
                        for (int i = 0; i < fullNameDiscip.size(); i++) {
                            fullNameDiscip.set(i, fullNameDiscip.get(i).trim());
                        }
                        //i - индекс подстроки в списке
                        for (int i = 0; i < fullNameDiscip.size(); i++) {
                            //Запоминаем индекс вида пары и должности препода
                            if (fullNameDiscip.get(i).contains("(")) {
                                indexView = i;
                                indexPost = i + 1;
                                break;
                            }
                        }
                        //Создаём 2 списка куда будем помещать название и ФИО
                        List<String> discipline = new ArrayList<>();
                        List<String> FCs = new ArrayList<>();
                        //Заполняем списки нужными данными
                        for (int discElms = 0; discElms < indexView; discElms++) {
                            discipline.add(fullNameDiscip.get(discElms));
                        }
                        for (int FCsElms = indexPost + 1; FCsElms < fullNameDiscip.size(); FCsElms++) {
                            FCs.add(fullNameDiscip.get(FCsElms));
                        }

                        //Создаём переменные для удобства переноса данных в БД

                        //Вывод дисциплины
                        nameDiscipline = String.join(" ", discipline);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(nameDiscipline);
                        //Вывод вида пары
                        disciplineView = fullNameDiscip.get(indexView);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(disciplineView);
                        //Вывод ФИО преподователя
                        teacherFCs = String.join(" ", FCs);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(teacherFCs);
                        //Вывод должности преподователя
                        teacherPost = fullNameDiscip.get(indexPost);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(teacherPost);

                        //Вывод разделения по виду недели
                        if (r == controlWeekView + 2)
                            controlWeekView = r;
                        if (numDenOrCom(sheet, controlWeekView)) {
                            if (r == controlWeekView) {
                                weekView = "ЧИСЛИТЕЛЬ";
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(weekView);
                            } else if (r == controlWeekView + 1) {
                                weekView = "ЗНАМЕНАТЕЛЬ";
                                //Следующую строку меняешь на добавление в БД
                                //System.out.println(weekView);
                            }
                        } else {
                            weekView = "ВСЕГДА";
                            //Следующую строку меняешь на добавление в БД
                            //System.out.println(weekView);
                        }
                        continue;
                    }
                    //Вывод дня недели
                    if (c == 0) {
                        day = String.valueOf(cell);
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(day);
                        continue;
                    }
                    //Вывод аудитории
                    if (c == auditCell) {
                        numAuditorium = String.valueOf(getValue(cell));
                        //Следующую строку меняешь на добавление в БД
                        //System.out.println(numAuditorium);
                        auditCell += 2;
                    }

                    /*//Направление
                    System.out.println(nameDirection);
                    //Профиль
                    System.out.println(nameProfile);
                    //Номер группы
                    if(!blockerGroup) {
                        //Следующую строку меняешь на добавление в БД
                        System.out.println(numGroup);
                        blockerGroup = true;
                    }*/

                    //Дисциплина
                    System.out.println(nameDiscipline);
                    //Вид пары
                    System.out.println(disciplineView);
                    //ФИО препода
                    System.out.println(teacherFCs);
                    //Должность
                    System.out.println(teacherPost);
                    //Вид недели
                    System.out.println(weekView);
                    //День недели
                    System.out.println(day);
                    //Время начала
                    System.out.println(startTime);
                    //Время конца
                    System.out.println(endTime);
                    //Аудитория
                    System.out.println(numAuditorium);

                    //Выводим информацию из ячейки, в зависимости от типа
                    //System.out.println(getValue(cell));
                }
                //Пропуск строки для удобства чтения
                System.out.println();
            }
        }
    }
}